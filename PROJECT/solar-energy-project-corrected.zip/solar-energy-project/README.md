# Solar Energy Management and Monitoring System
B.Tech II Year – DBMS Project
**Frontend:** HTML, CSS, JavaScript · **Backend:** Python FastAPI · **Database:** SQLite (SQL tables)

> This README is the project report / viva material. The website itself contains only the working application.

| Part | Address | Port |
|---|---|---|
| Backend FastAPI | http://127.0.0.1:8000 | 8000 |
| Swagger API docs | http://127.0.0.1:8000/docs | 8000 |
| Frontend (VS Code Live Server) | http://127.0.0.1:5500 | 5500 |
| Database | `backend/solar.db` (created automatically) | – |

---

## 1. Folder structure

```
solar-energy-project/
├── .vscode/settings.json     Live Server → 127.0.0.1:5500, serves the frontend folder
├── backend/
│   ├── main.py               FastAPI app: REST endpoints, SQL queries, algorithm flow
│   ├── algorithm.py          Steps 5–9 of the algorithm (pure calculations)
│   ├── database.py           SQLite connection + table creation
│   ├── models.py             Pydantic request validation
│   ├── schema.sql            CREATE TABLE statements (5 tables)
│   ├── requirements.txt      fastapi, uvicorn, pydantic
│   ├── Dockerfile            Container for the backend
│   └── .dockerignore
├── frontend/
│   ├── index.html            Home – today's figures, panel status, open alerts, upcoming maintenance
│   ├── dashboard.html        Dashboard – KPIs, generated vs consumed chart, efficiency chart, panel table
│   ├── add-panel.html        Solar Panels – add / edit / delete panels, live expected-output preview
│   ├── add-reading.html      Energy Readings – enter daily energy, see processed result, history
│   ├── reports.html          Reports – daily, monthly, panel-wise, user-wise; filters, CSV, print
│   ├── alerts.html           Alerts – open/resolved, resolve, schedule maintenance from an alert
│   ├── maintenance.html      Maintenance – schedule, mark done (auto-resolves panel alerts)
│   ├── users.html            Users – register / edit / delete panel owners
│   ├── favicon.svg
│   ├── css/style.css         All styling (responsive)
│   └── js/
│       ├── common.js         API calls, navbar, alert counter, tables, formatting, CSV export
│       └── charts.js         SVG bar + line charts with hover tooltips (no library)
└── README.md
```

---

## 2. Run it in VS Code

**Install once:** Python 3.10+ (tick "Add Python to PATH" on Windows) and the VS Code extensions **Python** and **Live Server**. Optional: **SQLite Viewer** to open `solar.db`.

1. `File → Open Folder → solar-energy-project`
2. **Terminal 1 – backend** (`Terminal → New Terminal`)

   Windows
   ```bash
   cd backend
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   uvicorn main:app --reload --port 8000
   ```
   Mac / Linux
   ```bash
   cd backend
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   uvicorn main:app --reload --port 8000
   ```
   (PowerShell blocks `activate`? Run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.)

3. Open **http://127.0.0.1:8000/docs** – Swagger shows every endpoint.
4. Click **Go Live** (bottom-right of VS Code) → **http://127.0.0.1:5500** opens the website.
   The navbar shows a green **Connected** dot when the backend is running.

On first start the database is created with sample data: 2 users, 3 panels, 14 days of readings (ending yesterday, so you can log *today's* reading in the demo), alerts and maintenance records.
**Reset:** stop uvicorn, delete `backend/solar.db`, start again.

**Docker (optional):**
```bash
docker build -t solar-backend ./backend
docker run -p 8000:8000 solar-backend
```

---

## 3. Algorithm – Solar Energy Monitoring and Alert Generation

| Step | Where it happens in the application |
|---|---|
| 1. Start | User opens the website |
| 2. Add solar panel details | **Solar Panels** page → `POST /panels` |
| 3. Enter daily generated energy and consumed energy | **Energy Readings** page → `POST /readings` |
| 4. Store the data in SQL database | `main.py → process_reading()` → `INSERT INTO energy_readings` |
| 5. Calculate energy balance = generated energy - consumed energy | `energy_balance()` |
| 6. Calculate expected energy = panel capacity × sunlight hours | `expected_output()` |
| 7. Calculate efficiency = generated energy / expected energy × 100 | `efficiency_percent()` |
| 8. Calculate savings = generated energy × cost per unit | `savings_amount()` |
| 9. If efficiency is less than 60%, create a low-efficiency alert | `build_alert()` → `INSERT INTO alerts` |
| 10. Display dashboard, reports, and alerts | Dashboard, Reports and Alerts pages read the stored data |
| 11. Stop | |

The **Dashboard** displays the full algorithm steps using the backend `/algorithm` API. After saving a reading, the **Energy Readings** page also shows all 11 steps with the calculated values.

**Worked example:** 5 kW panel, 5.5 sun-hours, ₹7/unit, limit 60%, generated 22 kWh, consumed 18 kWh
Expected = 5 × 5.5 = 27.5 kWh → Efficiency = 22 ÷ 27.5 × 100 = 80% → Balance = +4 kWh (surplus) → Savings = ₹154 → 80 ≥ 60, no alert.
With 9 kWh generated on a 4 kW panel: expected 22 kWh → 40.91% → **Medium alert**.

---

## 4. Database design

```sql
users           (user_id PK, name, email UNIQUE, phone, city, created_at)
solar_panels    (panel_id PK, user_id FK→users, panel_name, location, capacity_kw, sunlight_hours,
                 cost_per_unit, efficiency_limit, installation_date, status)
energy_readings (reading_id PK, panel_id FK→solar_panels, reading_date, generated_kwh, consumed_kwh,
                 expected_kwh, efficiency, energy_balance, savings, created_at,
                 UNIQUE(panel_id, reading_date))
alerts          (alert_id PK, panel_id FK→solar_panels, reading_id FK→energy_readings,
                 alert_type, message, severity, status, created_at)
maintenance     (maintenance_id PK, panel_id FK→solar_panels, maintenance_date, description,
                 technician, cost, status)
```
Full DDL with CHECK constraints and `ON DELETE CASCADE`: `backend/schema.sql`.

**Relationships:** users 1–N solar_panels 1–N energy_readings 1–N alerts; solar_panels 1–N maintenance.

**Normalization:** 1NF – atomic columns, every table has a PK. 2NF – single-column keys, no partial dependency. 3NF – owner data only in `users`, panel data only in `solar_panels`; readings store only `panel_id`.
`expected_kwh, efficiency, energy_balance, savings` are stored results of the algorithm: they keep that day's result correct even if the panel's capacity or tariff is edited later.

**SQL used:** INSERT (panels, readings, alerts), UPDATE (reading results, resolve alert, complete maintenance, edit panel/user), DELETE with cascade, SELECT with INNER JOIN / LEFT JOIN / 3-table JOIN, subqueries (latest efficiency per panel), GROUP BY date / month (`strftime`) / panel / user, aggregates COUNT, SUM, AVG, MIN, `CASE WHEN` (days below 60%), parameterized `?` queries against SQL injection.

---

## 5. REST API (Swagger groups)

| Group | Endpoints |
|---|---|
| Users | `POST /users`, `GET /users`, `GET/PUT/DELETE /users/{id}` |
| Solar Panels | `POST /panels`, `GET /panels`, `GET/PUT/DELETE /panels/{id}` |
| Energy Readings | `POST /readings` (runs Steps 4–9), `GET /readings?panel_id&start&end`, `DELETE /readings/{id}` |
| Alerts | `GET /alerts?status&panel_id`, `PUT /alerts/{id}/resolve` |
| Maintenance | `POST /maintenance`, `GET /maintenance?panel_id`, `PUT /maintenance/{id}/complete`, `DELETE /maintenance/{id}` |
| Reports | `GET /reports/summary`, `/reports/daily`, `/reports/monthly`, `/reports/panels`, `/reports/users` (panel/date filters) |

Invalid input (e.g. negative energy, bad email, invalid capacity) is rejected by Pydantic with HTTP 422; duplicate email / duplicate reading date return 400 with a readable message.

---

## 6. File explanations

| File | Purpose |
|---|---|
| `schema.sql` | Creates the 5 tables with PK, FK, CHECK, UNIQUE, ON DELETE CASCADE |
| `database.py` | `get_connection()` (enables foreign keys, dict rows), `init_db()` runs schema.sql |
| `models.py` | Pydantic models for users, panels, readings, maintenance |
| `algorithm.py` | One function per algorithm step 5–9 |
| `main.py` | App + CORS, `run_query()` helper with friendly DB errors, `process_reading()` (Steps 4–9 in order), sample data, all endpoints and report queries |
| `Dockerfile` | python:3.11-slim image running uvicorn on port 8000 |
| `common.js` | `API_URL`, `apiGet/apiSend`, navbar with live open-alert count, toasts, `renderTable`, formatting, CSV export |
| `charts.js` | `barChart()` and `lineChart()` drawn as SVG with tooltips and the dashed alert-limit line |
| each `.html` | One page; its script loads data from the API and handles its forms |

---

## 7. Methodology

Requirement Analysis → CO Mapping → Database Design → Frontend Design → Backend API Development → Database Integration → SQL Reports → Algorithm Implementation → Testing → Final Demo

1. **Requirement Analysis** – owners need to record panels and daily energy, see efficiency, balance and savings, and be warned about poor output.
2. **CO Mapping** – each feature mapped to CO1–CO6 (section 8).
3. **Database Design** – ER model → 5 normalized tables with PK/FK/constraints.
4. **Frontend Design** – 8 responsive pages in HTML/CSS/JS using `fetch()`.
5. **Backend REST API** – FastAPI routes with Pydantic validation and Swagger.
6. **Database Integration** – Python `sqlite3`, parameterized queries.
7. **SQL Reports** – JOIN, GROUP BY and aggregate queries for dashboard and reports.
8. **Algorithm Implementation** – `algorithm.py` + `process_reading()`.
9. **Testing** – sample data plus the test cases below.
10. **Final Demo** – section 9.

| Test | Expected |
|---|---|
| 22 kWh on 5 kW panel (5.5 h) | 80%, no alert |
| 9 kWh on 4 kW panel (5.5 h) | 40.91%, Medium alert |
| Same panel + same date again | "A reading for this panel on this date already exists." |
| Negative energy | 422 validation error |
| Reading for Inactive panel | 400 "Panel is Inactive…" |
| Duplicate email | "This email is already registered." |
| Mark maintenance done | That panel's open alerts become Resolved |
| Delete panel | Its readings, alerts, maintenance removed (CASCADE) |

---

## 8. CO mapping

| CO | Requirement | Implemented in |
|---|---|---|
| CO1 | Normalized schema, SQL tables, PK/FK, INSERT/UPDATE/SELECT, joins, aggregate reports, backend DB integration | `schema.sql`, `database.py`, queries in `main.py`, Reports & Dashboard pages |
| CO2 | SQL vs NoSQL, why SQL | Below |
| CO3 | FastAPI REST, Pydantic validation, Swagger/OpenAPI | `main.py`, `models.py`, `/docs` |
| CO4 | Endpoints for users, panels, readings, alerts, reports | Section 5 |
| CO5 | Microservice architecture | Below |
| CO6 | Dockerfile, full-stack demo, integration | `backend/Dockerfile`, section 9 |

**CO2 – SQL vs NoSQL**

| | SQL (SQLite) | NoSQL (e.g. MongoDB) |
|---|---|---|
| Model | Tables, rows, columns | Documents / key-value |
| Schema | Fixed | Flexible |
| Relations | PK/FK, JOIN | Embedding, limited joins |
| Consistency | ACID | Often eventual |
| Best for | Structured, related data and reports | Huge or unstructured data |

SQL is chosen because the data is structured and always has the same fields; it is related (user → panel → reading → alert) and foreign keys stop invalid links; reports need JOIN and GROUP BY; constraints (CHECK, UNIQUE) guard data quality; energy and money values need ACID consistency; and daily readings are small data that do not need NoSQL scaling.

**CO5 – microservice mapping.** The app runs as one FastAPI service, but routes are grouped so they can be split:

| Service | Endpoints | Tables | Future port |
|---|---|---|---|
| User Service | /users, /panels | users, solar_panels | 8001 |
| Energy Service | /readings (algorithm) | energy_readings | 8002 |
| Report Service | /reports/* | read-only | 8003 |
| Alert Service | /alerts, /maintenance | alerts, maintenance | 8004 |

Energy Service would call Alert Service when efficiency is below 60%; an API gateway on port 8000 would route frontend requests; each service would get its own Dockerfile.

---

## 9. Demo script

1. Start backend; show Swagger at `/docs`.
2. Go Live → Home shows today's figures (0 so far), panel status cards and open alerts.
3. **Users** → register a new owner.
4. **Solar Panels** → add a 4 kW panel; the preview shows expected 22 kWh/day.
5. **Energy Readings** → select it, enter 9 kWh generated / 12 consumed → result shows expected 22 kWh, 40.91%, −3 kWh deficit, ₹63, **Medium alert**. The Alerts badge in the navbar increases.
6. Enter the same date again → duplicate is blocked.
7. **Alerts** → Schedule maintenance (pre-filled) → **Maintenance** → Mark done → alert resolved.
8. **Dashboard** → change panel/period filters; hover charts.
9. **Reports** → daily/monthly/panel/user tabs, Export CSV, Print.
10. Open `solar.db` in SQLite Viewer to show the stored rows.

---

## 10. Viva – simple answers

- **Project in one line:** a website where solar panel owners record daily energy; the system stores it in SQL, calculates efficiency, balance and savings, and raises an alert when a panel underperforms.
- **Primary key:** uniquely identifies a row, e.g. `panel_id`.
- **Foreign key:** links to another table's PK, e.g. `energy_readings.panel_id → solar_panels.panel_id`; a reading cannot exist for a non-existent panel.
- **ON DELETE CASCADE:** deleting a panel automatically deletes its readings, alerts and maintenance.
- **INNER vs LEFT JOIN:** INNER shows panels with their owner; LEFT keeps panels that have no readings yet (shown as 0).
- **Expected output:** capacity × average sunlight hours, fetched from the panel record.
- **Why 60% for alert?** The project uses a fixed low-efficiency rule: if efficiency is below 60%, the system creates an alert.
- **Pydantic:** validates input before it reaches the database.
- **REST:** GET read, POST create, PUT update, DELETE remove, data as JSON.
- **CORS:** lets the page on port 5500 call the API on port 8000.
- **SQL injection:** prevented by `?` placeholders.
- **Docker:** packages the backend with its dependencies so it runs the same anywhere.
- **Future scope:** IoT sensor input, weather API for sunlight hours, login, SMS/email alerts, PostgreSQL.
