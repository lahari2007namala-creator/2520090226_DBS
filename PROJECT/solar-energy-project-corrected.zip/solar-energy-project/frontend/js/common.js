// =====================================================================
// common.js - shared functions for every page
// =====================================================================
const API_URL = "http://127.0.0.1:8000";

// ---------- Calls to the backend ----------
async function apiGet(path, params) {
  let url = API_URL + path;
  if (params) {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== "" && v !== null && v !== undefined) q.append(k, v); });
    if ([...q].length) url += "?" + q.toString();
  }
  const res = await fetch(url);
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}

async function apiSend(method, path, data) {
  const res = await fetch(API_URL + path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: data ? JSON.stringify(data) : null,
  });
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}

async function readError(res) {
  try {
    const body = await res.json();
    if (Array.isArray(body.detail)) {
      return body.detail.map(d => `${d.loc[d.loc.length - 1].replace(/_/g, " ")}: ${d.msg}`).join("; ");
    }
    return body.detail || res.statusText;
  } catch (e) {
    return res.statusText;
  }
}

// ---------- Navbar ----------
const PAGES = [
  ["index.html", "Home"],
  ["dashboard.html", "Dashboard"],
  ["add-panel.html", "Solar Panels"],
  ["add-reading.html", "Energy Readings"],
  ["reports.html", "Reports"],
  ["alerts.html", "Alerts"],
  ["maintenance.html", "Maintenance"],
  ["users.html", "Users"],
];

function buildNavbar() {
  const current = location.pathname.split("/").pop() || "index.html";
  const links = PAGES.map(([file, name]) =>
    `<a href="${file}" class="${file === current ? "active" : ""}">${name}${file === "alerts.html" ? '<span class="count" id="alertCount" hidden></span>' : ""}</a>`
  ).join("");
  const nav = document.createElement("nav");
  nav.className = "navbar";
  nav.innerHTML = `
    <a class="brand" href="index.html"><span class="sun-dot"></span> Solar EMS</a>
    <div class="nav-links">${links}</div>
    <span class="conn" id="conn">Connecting…</span>`;
  document.body.prepend(nav);

  const toast = document.createElement("div");
  toast.id = "toast";
  document.body.appendChild(toast);

  refreshAlertCount();
}

async function refreshAlertCount() {
  const conn = document.getElementById("conn");
  try {
    const open = await apiGet("/alerts", { status: "Open" });
    conn.textContent = "Connected";
    conn.className = "conn on";
    const badge = document.getElementById("alertCount");
    badge.hidden = open.length === 0;
    badge.textContent = open.length;
  } catch (e) {
    conn.textContent = "Server offline";
    conn.className = "conn off";
  }
}

// ---------- UI helpers ----------
let toastTimer;
function toast(text, isError) {
  const el = document.getElementById("toast");
  el.textContent = text;
  el.className = "show" + (isError ? " err" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.className = ""), 3500);
}

function num(v, digits) {
  if (typeof digits !== "number") digits = 2;   // also safe when used as a table formatter
  return Number(v ?? 0).toLocaleString("en-IN", { maximumFractionDigits: digits });
}
function kwh(v) { return num(v) + " kWh"; }
function money(v) { return "₹ " + num(v); }
function today() { return new Date().toLocaleDateString("en-CA"); }            // YYYY-MM-DD
function daysAgo(n) { const d = new Date(); d.setDate(d.getDate() - n); return d.toLocaleDateString("en-CA"); }
function niceDate(s) {
  if (!s) return "-";
  return new Date(s.slice(0, 10) + "T00:00:00").toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function effBadge(eff, limit = 60) {
  if (eff === null || eff === undefined) return '<span class="badge grey">No data</span>';
  const cls = eff >= limit ? "good" : eff >= limit * 0.66 ? "warn" : "bad";
  return `<span class="badge ${cls}">${num(eff)}%</span>`;
}
function balance(b) {
  return b >= 0 ? `<span class="pos">+${num(b)}</span>` : `<span class="neg">${num(b)}</span>`;
}

// Build a table. columns = [{key, label, fmt(value,row), num:true}]
function renderTable(el, rows, columns, footer) {
  if (!rows.length) { el.innerHTML = '<div class="empty">No records found.</div>'; return; }
  const head = columns.map(c => `<th class="${c.num ? "num" : ""}">${c.label}</th>`).join("");
  const body = rows.map(r => "<tr>" + columns.map(c => {
    const v = r[c.key];
    return `<td class="${c.num ? "num" : ""} ${c.wrap ? "wrap" : ""}">${c.fmt ? c.fmt(v, r) : esc(v ?? "-")}</td>`;
  }).join("") + "</tr>").join("");
  const foot = footer ? `<tfoot><tr>${footer.map(f => `<td class="num">${f}</td>`).join("")}</tr></tfoot>` : "";
  el.innerHTML = `<div class="table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody>${foot}</table></div>`;
}

// Fill a <select> with panels
async function fillPanelSelect(select, { allOption = false, activeOnly = false } = {}) {
  const panels = await apiGet("/panels");
  const list = activeOnly ? panels.filter(p => p.status === "Active") : panels;
  select.innerHTML = (allOption ? '<option value="">All panels</option>' : "") +
    list.map(p => `<option value="${p.panel_id}">${esc(p.panel_name)}</option>`).join("");
  return panels;
}

// Download rows as a CSV file
function downloadCSV(filename, rows) {
  if (!rows.length) return toast("Nothing to export", true);
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(",")].concat(rows.map(r => keys.map(k => `"${String(r[k] ?? "").replace(/"/g, '""')}"`).join(","))).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = filename;
  a.click();
}

function serverDown(el) {
  el.innerHTML = '<div class="banner bad">Cannot connect to the server. Please start the backend and refresh this page.</div>';
}

document.addEventListener("DOMContentLoaded", buildNavbar);
