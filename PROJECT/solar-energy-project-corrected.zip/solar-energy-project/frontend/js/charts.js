// =====================================================================
// charts.js - small SVG charts (no external library needed)
// barChart : grouped bars (e.g. generated vs consumed per day)
// lineChart: one line + dashed limit line (e.g. efficiency vs limit)
// =====================================================================
const W = 800, H = 280, PAD = { l: 48, r: 16, t: 14, b: 34 };

function niceMax(v) {
  if (v <= 0) return 10;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  const n = v / p;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p;
}

function axes(maxY, labels, xOf, suffix = "") {
  let g = "";
  for (let i = 0; i <= 4; i++) {
    const val = (maxY / 4) * i;
    const y = PAD.t + (H - PAD.t - PAD.b) * (1 - i / 4);
    g += `<line x1="${PAD.l}" x2="${W - PAD.r}" y1="${y}" y2="${y}" stroke="var(--grid)"/>`;
    g += `<text x="${PAD.l - 8}" y="${y + 4}" text-anchor="end" font-size="11" fill="var(--muted)">${+val.toFixed(1)}${suffix}</text>`;
  }
  const step = Math.ceil(labels.length / 10);  // show max ~10 labels
  labels.forEach((l, i) => {
    if (i % step === 0) {
      g += `<text x="${xOf(i)}" y="${H - PAD.b + 18}" text-anchor="middle" font-size="11" fill="var(--muted)">${l}</text>`;
    }
  });
  return g;
}

function topRoundedBar(x, y, w, h) {
  const r = Math.min(4, w / 2, h);
  const b = y + h;
  return `M${x},${b} L${x},${y + r} Q${x},${y} ${x + r},${y} L${x + w - r},${y} Q${x + w},${y} ${x + w},${y + r} L${x + w},${b} Z`;
}

function attachTooltip(box, labels, slotW, xOf, htmlFor, onMove) {
  const svg = box.querySelector("svg");
  const tip = document.createElement("div");
  tip.className = "tooltip";
  box.appendChild(tip);
  svg.querySelectorAll(".hit").forEach(hit => {
    const i = +hit.dataset.i;
    hit.addEventListener("mouseenter", () => { tip.innerHTML = htmlFor(i); tip.style.display = "block"; onMove && onMove(i, true); });
    hit.addEventListener("mousemove", e => {
      const rect = box.getBoundingClientRect();
      let left = e.clientX - rect.left + 14;
      if (left + tip.offsetWidth > rect.width) left = e.clientX - rect.left - tip.offsetWidth - 14;
      tip.style.left = left + "px";
      tip.style.top = (e.clientY - rect.top - 10) + "px";
    });
    hit.addEventListener("mouseleave", () => { tip.style.display = "none"; onMove && onMove(i, false); });
  });
}

// series = [{ name, color, values: [...] }]
function barChart(box, labels, series, unit = "kWh") {
  if (!labels.length) { box.innerHTML = '<div class="empty">No readings for this selection.</div>'; return; }
  const maxY = niceMax(Math.max(...series.flatMap(s => s.values)));
  const plotW = W - PAD.l - PAD.r, plotH = H - PAD.t - PAD.b;
  const slot = plotW / labels.length;
  const barW = Math.min(22, (slot * 0.7 - 2 * (series.length - 1)) / series.length);
  const groupW = barW * series.length + 2 * (series.length - 1);
  const xOf = i => PAD.l + slot * i + slot / 2;
  let marks = "";
  labels.forEach((_, i) => {
    series.forEach((s, k) => {
      const h = (s.values[i] / maxY) * plotH;
      const x = xOf(i) - groupW / 2 + k * (barW + 2);
      marks += `<path d="${topRoundedBar(x, PAD.t + plotH - h, barW, h)}" fill="${s.color}"/>`;
    });
    marks += `<rect class="hit" data-i="${i}" x="${PAD.l + slot * i}" y="${PAD.t}" width="${slot}" height="${plotH}" fill="transparent"/>`;
  });
  box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img">${axes(maxY, labels, xOf)}
    <line x1="${PAD.l}" x2="${W - PAD.r}" y1="${PAD.t + plotH}" y2="${PAD.t + plotH}" stroke="#cbd2dc"/>${marks}</svg>`;
  attachTooltip(box, labels, slot, xOf, i =>
    `<b>${labels[i]}</b>` + series.map(s =>
      `<div class="trow"><span><i style="background:${s.color}"></i>${s.name}</span><span>${num(s.values[i])} ${unit}</span></div>`).join(""));
}

// line chart with optional dashed limit
function lineChart(box, labels, values, { name = "Efficiency", color = "var(--con)", limit = null, suffix = "%" } = {}) {
  if (!labels.length) { box.innerHTML = '<div class="empty">No readings for this selection.</div>'; return; }
  const maxY = Math.max(100, niceMax(Math.max(...values)));
  const plotW = W - PAD.l - PAD.r, plotH = H - PAD.t - PAD.b;
  const slot = plotW / labels.length;
  const xOf = i => PAD.l + slot * i + slot / 2;
  const yOf = v => PAD.t + plotH * (1 - v / maxY);
  const pts = values.map((v, i) => `${xOf(i)},${yOf(v)}`).join(" ");
  let marks = "";
  if (limit !== null) {
    marks += `<line x1="${PAD.l}" x2="${W - PAD.r}" y1="${yOf(limit)}" y2="${yOf(limit)}" stroke="var(--bad)" stroke-width="1.5" stroke-dasharray="6 4"/>`;
    marks += `<text x="${W - PAD.r}" y="${yOf(limit) - 6}" text-anchor="end" font-size="11" fill="var(--bad)">Alert limit ${limit}%</text>`;
  }
  marks += `<line class="cross" x1="0" x2="0" y1="${PAD.t}" y2="${PAD.t + plotH}" stroke="#9ca3af" visibility="hidden"/>`;
  marks += `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round"/>`;
  values.forEach((v, i) => {
    const low = limit !== null && v < limit;
    marks += `<circle cx="${xOf(i)}" cy="${yOf(v)}" r="${low ? 5 : 4}" fill="${low ? "var(--bad)" : color}" stroke="#fff" stroke-width="2"/>`;
  });
  labels.forEach((_, i) => {
    marks += `<rect class="hit" data-i="${i}" x="${PAD.l + slot * i}" y="${PAD.t}" width="${slot}" height="${plotH}" fill="transparent"/>`;
  });
  box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img">${axes(maxY, labels, xOf, suffix)}${marks}</svg>`;
  const cross = box.querySelector(".cross");
  attachTooltip(box, labels, slot, xOf,
    i => `<b>${labels[i]}</b><div class="trow"><span>${name}</span><span>${num(values[i])}${suffix}</span></div>` +
         (limit !== null && values[i] < limit ? '<div style="color:var(--bad);margin-top:2px">Below limit</div>' : ""),
    (i, on) => { cross.setAttribute("x1", xOf(i)); cross.setAttribute("x2", xOf(i)); cross.setAttribute("visibility", on ? "visible" : "hidden"); });
}
