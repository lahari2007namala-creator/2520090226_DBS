"""
Solar Energy Monitoring and Alert Generation Algorithm
Steps 5 to 9 (pure calculations, no database code).
Steps 1-4 and 10-11 are handled in main.py and the frontend.
"""


# Step 6: Calculate expected energy
def expected_output(panel):
    """Expected daily energy of a panel = capacity (kW) x average sunlight hours."""
    return round(panel["capacity_kw"] * panel["sunlight_hours"], 2)


# Step 7: Calculate efficiency percentage
def efficiency_percent(generated_kwh, expected_kwh):
    if expected_kwh <= 0:
        return 0.0
    return round(generated_kwh / expected_kwh * 100, 2)


# Step 5: Calculate energy balance
def energy_balance(generated_kwh, consumed_kwh):
    """Positive = surplus energy, negative = deficit (taken from grid)."""
    return round(generated_kwh - consumed_kwh, 2)


# Step 8: Calculate savings amount
def savings_amount(generated_kwh, cost_per_unit):
    return round(generated_kwh * cost_per_unit, 2)


# Step 9: If efficiency is less than 60%, create alert
def build_alert(efficiency, limit, panel_name):
    """Returns alert details, or None when efficiency is within limit."""
    if efficiency >= limit:
        return None
    severity = "High" if efficiency < limit * 0.66 else "Medium"
    message = (f"{panel_name} produced only {efficiency}% of expected output "
               f"(limit {limit}%). Check for dust, shading or wiring faults.")
    return {"alert_type": "Low Efficiency", "severity": severity, "message": message}
