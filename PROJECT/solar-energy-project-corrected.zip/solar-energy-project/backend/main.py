"""
Solar Energy Management and Monitoring System - FastAPI backend
Run from the backend folder:  uvicorn main:app --reload --port 8000
"""
import sqlite3
from datetime import date, timedelta
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from algorithm import expected_output, efficiency_percent, energy_balance, savings_amount, build_alert
from database import get_connection, init_db, rows_to_list
from models import UserCreate, PanelCreate, ReadingCreate, MaintenanceCreate

app = FastAPI(
    title="Solar Energy Management and Monitoring System",
    description="REST API for users, solar panels, energy readings, alerts, maintenance and reports.",
    version="2.0.0",
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

ALERT_LIMIT = 60.0

ALGORITHM_STEPS = [
    "Start",
    "Add solar panel details",
    "Enter daily generated energy and consumed energy",
    "Store the data in SQL database",
    "Calculate energy balance = generated energy - consumed energy",
    "Calculate expected energy = panel capacity x sunlight hours",
    "Calculate efficiency = generated energy / expected energy x 100",
    "Calculate savings = generated energy x cost per unit",
    "If efficiency is less than 60%, create a low-efficiency alert",
    "Display dashboard, reports, and alerts",
    "Stop",
]


# ---------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------
def run_query(sql, params=(), fetch="all"):
    """fetch='all' -> list of dicts, 'one' -> dict or None, 'none' -> last inserted id"""
    conn = get_connection()
    try:
        cur = conn.execute(sql, params)
        conn.commit()
        if fetch == "all":
            return rows_to_list(cur.fetchall())
        if fetch == "one":
            row = cur.fetchone()
            return dict(row) if row else None
        return cur.lastrowid
    except sqlite3.IntegrityError as e:
        msg = str(e)
        if "users.email" in msg:
            msg = "This email is already registered."
        elif "energy_readings.panel_id, energy_readings.reading_date" in msg:
            msg = "A reading for this panel on this date already exists."
        elif "FOREIGN KEY" in msg:
            msg = "Linked record does not exist."
        raise HTTPException(status_code=400, detail=msg)
    finally:
        conn.close()


def date_filter(column, start, end, params):
    """Build ' AND column >= ? AND column <= ?' for optional date range."""
    sql = ""
    if start:
        sql += f" AND {column} >= ?"
        params.append(str(start))
    if end:
        sql += f" AND {column} <= ?"
        params.append(str(end))
    return sql


def get_panel_or_404(panel_id):
    panel = run_query("SELECT * FROM solar_panels WHERE panel_id = ?", (panel_id,), "one")
    if panel is None:
        raise HTTPException(status_code=404, detail="Solar panel not found")
    return panel


def get_user_or_404(user_id):
    user = run_query("SELECT * FROM users WHERE user_id = ?", (user_id,), "one")
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user


# ---------------------------------------------------------------------
# Solar Energy Monitoring and Alert Generation Algorithm (Steps 4 - 9)
# ---------------------------------------------------------------------
def process_reading(r: ReadingCreate):
    panel = get_panel_or_404(r.panel_id)
    if panel["status"] != "Active":
        raise HTTPException(status_code=400, detail="Panel is Inactive. Activate it before adding readings.")

    # Step 4: Store the data in database
    reading_id = run_query(
        "INSERT INTO energy_readings (panel_id, reading_date, generated_kwh, consumed_kwh) VALUES (?, ?, ?, ?)",
        (r.panel_id, str(r.reading_date), r.generated_kwh, r.consumed_kwh), "none")

    # Step 5: Calculate energy balance
    balance = energy_balance(r.generated_kwh, r.consumed_kwh)
    # Step 6: Calculate expected energy
    expected = expected_output(panel)
    # Step 7: Calculate efficiency percentage
    efficiency = efficiency_percent(r.generated_kwh, expected)
    # Step 8: Calculate savings amount
    savings = savings_amount(r.generated_kwh, panel["cost_per_unit"])

    run_query("""UPDATE energy_readings
                 SET expected_kwh = ?, efficiency = ?, energy_balance = ?, savings = ?
                 WHERE reading_id = ?""",
              (expected, efficiency, balance, savings, reading_id), "none")

    # Step 9: If efficiency is less than 60%, create alert
    alert = build_alert(efficiency, ALERT_LIMIT, panel["panel_name"])
    alert_id = None
    if alert:
        alert_id = run_query(
            "INSERT INTO alerts (panel_id, reading_id, alert_type, message, severity) VALUES (?, ?, ?, ?, ?)",
            (r.panel_id, reading_id, alert["alert_type"], alert["message"], alert["severity"]), "none")

    return {
        "reading_id": reading_id,
        "panel_name": panel["panel_name"],
        "reading_date": str(r.reading_date),
        "generated_kwh": r.generated_kwh,
        "consumed_kwh": r.consumed_kwh,
        "expected_kwh": expected,
        "efficiency": efficiency,
        "efficiency_limit": ALERT_LIMIT,
        "energy_balance": balance,
        "savings": savings,
        "alert_id": alert_id,
        "alert": alert,
        "algorithm_steps": [{"step": i + 1, "description": text} for i, text in enumerate(ALGORITHM_STEPS)],
    }


# ---------------------------------------------------------------------
# Sample data (loaded only when the database is empty)
# ---------------------------------------------------------------------
def seed_sample_data():
    if run_query("SELECT COUNT(*) AS c FROM users", fetch="one")["c"] > 0:
        return
    add_user = "INSERT INTO users (name, email, phone, city) VALUES (?, ?, ?, ?)"
    u1 = run_query(add_user, ("Ravi Kumar", "ravi.kumar@gmail.com", "9876543210", "Hyderabad"), "none")
    u2 = run_query(add_user, ("Sneha Reddy", "sneha.reddy@gmail.com", "9123456780", "Warangal"), "none")

    add_panel = """INSERT INTO solar_panels (user_id, panel_name, location, capacity_kw, sunlight_hours,
                   cost_per_unit, efficiency_limit, installation_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"""
    p1 = run_query(add_panel, (u1, "Rooftop Array A", "House Roof, Kukatpally", 5, 5.5, 7, 60, "2025-01-10"), "none")
    p2 = run_query(add_panel, (u1, "Garage Panel B", "Garage Top, Kukatpally", 3, 5.5, 7, 60, "2025-06-15"), "none")
    p3 = run_query(add_panel, (u2, "Farm Array C", "Farm Shed, Hanamkonda", 10, 6, 6.5, ALERT_LIMIT, "2024-11-20"), "none")

    # 14 days of (generated, consumed) per panel; a few days are low on purpose
    data = {
        p1: [(22, 18), (24, 19), (21, 17), (15, 18), (23, 20), (25, 18), (10, 17),
             (22, 19), (24, 18), (23, 17), (20, 19), (14, 18), (24, 20), (23, 18)],
        p2: [(13, 10), (12, 11), (7, 10), (13.5, 9), (12, 10), (14, 11), (11, 10),
             (12.5, 10), (13, 9), (8, 11), (13, 10), (12, 10), (14, 9), (12, 11)],
        p3: [(45, 30), (48, 32), (42, 31), (26, 30), (46, 29), (44, 33), (47, 31),
             (49, 30), (45, 32), (43, 30), (47, 31), (46, 29), (35, 30), (48, 32)],
    }
    for panel_id, days in data.items():
        for i, (g, c) in enumerate(days):
            d = date.today() - timedelta(days=14 - i)   # last 14 days, ending yesterday
            process_reading(ReadingCreate(panel_id=panel_id, reading_date=d, generated_kwh=g, consumed_kwh=c))

    add_m = """INSERT INTO maintenance (panel_id, maintenance_date, description, technician, cost, status)
               VALUES (?, ?, ?, ?, ?, ?)"""
    run_query(add_m, (p1, str(date.today() - timedelta(days=6)), "Panel surface cleaning", "Suresh", 500, "Completed"), "none")
    run_query(add_m, (p2, str(date.today() + timedelta(days=2)), "Inverter wiring inspection", "Mahesh", 1200, "Scheduled"), "none")


init_db()
seed_sample_data()


@app.get("/", tags=["Health"])
def health():
    return {"status": "running"}


@app.get("/algorithm", tags=["Algorithm"])
def algorithm_steps():
    return {
        "name": "Solar Energy Monitoring and Alert Generation Algorithm",
        "steps": [{"step": i + 1, "description": text} for i, text in enumerate(ALGORITHM_STEPS)],
    }


# =====================================================================
# USERS
# =====================================================================
@app.post("/users", tags=["Users"])
def create_user(user: UserCreate):
    user_id = run_query("INSERT INTO users (name, email, phone, city) VALUES (?, ?, ?, ?)",
                        (user.name, user.email, user.phone, user.city), "none")
    return {"message": "User registered", "user_id": user_id}


@app.get("/users", tags=["Users"])
def list_users():
    return run_query("""
        SELECT u.*, COUNT(p.panel_id) AS panel_count
        FROM users u LEFT JOIN solar_panels p ON u.user_id = p.user_id
        GROUP BY u.user_id ORDER BY u.name""")


@app.get("/users/{user_id}", tags=["Users"])
def get_user(user_id: int):
    return get_user_or_404(user_id)


@app.put("/users/{user_id}", tags=["Users"])
def update_user(user_id: int, user: UserCreate):
    get_user_or_404(user_id)
    run_query("UPDATE users SET name = ?, email = ?, phone = ?, city = ? WHERE user_id = ?",
              (user.name, user.email, user.phone, user.city, user_id), "none")
    return {"message": "User updated"}


@app.delete("/users/{user_id}", tags=["Users"])
def delete_user(user_id: int):
    get_user_or_404(user_id)
    run_query("DELETE FROM users WHERE user_id = ?", (user_id,), "none")
    return {"message": "User deleted"}


# =====================================================================
# SOLAR PANELS  (Step 2)
# =====================================================================
@app.post("/panels", tags=["Solar Panels"])
def create_panel(p: PanelCreate):
    get_user_or_404(p.user_id)
    panel_id = run_query(
        """INSERT INTO solar_panels (user_id, panel_name, location, capacity_kw, sunlight_hours,
           cost_per_unit, efficiency_limit, installation_date, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (p.user_id, p.panel_name, p.location, p.capacity_kw, p.sunlight_hours, p.cost_per_unit,
         ALERT_LIMIT, str(p.installation_date) if p.installation_date else None, p.status), "none")
    return {"message": "Solar panel added", "panel_id": panel_id,
            "expected_daily_kwh": round(p.capacity_kw * p.sunlight_hours, 2)}


@app.get("/panels", tags=["Solar Panels"])
def list_panels():
    return run_query("""
        SELECT p.*, u.name AS owner_name,
               ROUND(p.capacity_kw * p.sunlight_hours, 2) AS expected_daily_kwh,
               (SELECT efficiency FROM energy_readings r
                 WHERE r.panel_id = p.panel_id ORDER BY reading_date DESC LIMIT 1) AS latest_efficiency,
               (SELECT reading_date FROM energy_readings r
                 WHERE r.panel_id = p.panel_id ORDER BY reading_date DESC LIMIT 1) AS latest_reading_date,
               (SELECT COUNT(*) FROM alerts a
                 WHERE a.panel_id = p.panel_id AND a.status = 'Open') AS open_alerts
        FROM solar_panels p
        JOIN users u ON p.user_id = u.user_id
        ORDER BY p.panel_id""")


@app.get("/panels/{panel_id}", tags=["Solar Panels"])
def get_panel(panel_id: int):
    return get_panel_or_404(panel_id)


@app.put("/panels/{panel_id}", tags=["Solar Panels"])
def update_panel(panel_id: int, p: PanelCreate):
    get_panel_or_404(panel_id)
    get_user_or_404(p.user_id)
    run_query("""UPDATE solar_panels SET user_id = ?, panel_name = ?, location = ?, capacity_kw = ?,
                 sunlight_hours = ?, cost_per_unit = ?, efficiency_limit = ?, installation_date = ?, status = ?
                 WHERE panel_id = ?""",
              (p.user_id, p.panel_name, p.location, p.capacity_kw, p.sunlight_hours, p.cost_per_unit,
               ALERT_LIMIT, str(p.installation_date) if p.installation_date else None,
               p.status, panel_id), "none")
    return {"message": "Solar panel updated"}


@app.delete("/panels/{panel_id}", tags=["Solar Panels"])
def delete_panel(panel_id: int):
    get_panel_or_404(panel_id)
    run_query("DELETE FROM solar_panels WHERE panel_id = ?", (panel_id,), "none")
    return {"message": "Solar panel deleted"}


# =====================================================================
# ENERGY READINGS  (Steps 3 - 9)
# =====================================================================
@app.post("/readings", tags=["Energy Readings"])
def create_reading(r: ReadingCreate):
    return process_reading(r)


@app.get("/readings", tags=["Energy Readings"])
def list_readings(panel_id: Optional[int] = None, start: Optional[date] = None,
                  end: Optional[date] = None, limit: int = 500):
    params = []
    sql = """SELECT r.*, p.panel_name, p.efficiency_limit
             FROM energy_readings r JOIN solar_panels p ON r.panel_id = p.panel_id
             WHERE 1 = 1"""
    if panel_id:
        sql += " AND r.panel_id = ?"
        params.append(panel_id)
    sql += date_filter("r.reading_date", start, end, params)
    sql += " ORDER BY r.reading_date DESC, r.reading_id DESC LIMIT ?"
    params.append(limit)
    return run_query(sql, params)


@app.delete("/readings/{reading_id}", tags=["Energy Readings"])
def delete_reading(reading_id: int):
    if run_query("SELECT reading_id FROM energy_readings WHERE reading_id = ?", (reading_id,), "one") is None:
        raise HTTPException(status_code=404, detail="Reading not found")
    run_query("DELETE FROM energy_readings WHERE reading_id = ?", (reading_id,), "none")
    return {"message": "Reading deleted"}


# =====================================================================
# ALERTS  (Step 9 output)
# =====================================================================
@app.get("/alerts", tags=["Alerts"])
def list_alerts(status: Optional[str] = None, panel_id: Optional[int] = None):
    params = []
    sql = """SELECT a.*, p.panel_name, r.reading_date, r.efficiency, r.generated_kwh, r.expected_kwh
             FROM alerts a
             JOIN solar_panels p    ON a.panel_id = p.panel_id
             JOIN energy_readings r ON a.reading_id = r.reading_id
             WHERE 1 = 1"""
    if status:
        sql += " AND a.status = ?"
        params.append(status)
    if panel_id:
        sql += " AND a.panel_id = ?"
        params.append(panel_id)
    return run_query(sql + " ORDER BY a.status = 'Resolved', r.reading_date DESC", params)


@app.put("/alerts/{alert_id}/resolve", tags=["Alerts"])
def resolve_alert(alert_id: int):
    if run_query("SELECT alert_id FROM alerts WHERE alert_id = ?", (alert_id,), "one") is None:
        raise HTTPException(status_code=404, detail="Alert not found")
    run_query("UPDATE alerts SET status = 'Resolved' WHERE alert_id = ?", (alert_id,), "none")
    return {"message": "Alert resolved"}


# =====================================================================
# MAINTENANCE
# =====================================================================
@app.post("/maintenance", tags=["Maintenance"])
def create_maintenance(m: MaintenanceCreate):
    get_panel_or_404(m.panel_id)
    mid = run_query("""INSERT INTO maintenance (panel_id, maintenance_date, description, technician, cost, status)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (m.panel_id, str(m.maintenance_date), m.description, m.technician, m.cost, m.status), "none")
    return {"message": "Maintenance scheduled", "maintenance_id": mid}


@app.get("/maintenance", tags=["Maintenance"])
def list_maintenance(panel_id: Optional[int] = None):
    params = []
    sql = """SELECT m.*, p.panel_name FROM maintenance m
             JOIN solar_panels p ON m.panel_id = p.panel_id WHERE 1 = 1"""
    if panel_id:
        sql += " AND m.panel_id = ?"
        params.append(panel_id)
    return run_query(sql + " ORDER BY m.status = 'Completed', m.maintenance_date DESC", params)


@app.put("/maintenance/{maintenance_id}/complete", tags=["Maintenance"])
def complete_maintenance(maintenance_id: int):
    m = run_query("SELECT * FROM maintenance WHERE maintenance_id = ?", (maintenance_id,), "one")
    if m is None:
        raise HTTPException(status_code=404, detail="Maintenance record not found")
    run_query("UPDATE maintenance SET status = 'Completed' WHERE maintenance_id = ?", (maintenance_id,), "none")
    # Completing maintenance resolves that panel's open alerts
    run_query("UPDATE alerts SET status = 'Resolved' WHERE panel_id = ? AND status = 'Open'", (m["panel_id"],), "none")
    return {"message": "Maintenance completed and panel alerts resolved"}


@app.delete("/maintenance/{maintenance_id}", tags=["Maintenance"])
def delete_maintenance(maintenance_id: int):
    run_query("DELETE FROM maintenance WHERE maintenance_id = ?", (maintenance_id,), "none")
    return {"message": "Maintenance record deleted"}


# =====================================================================
# REPORTS  (Step 10)
# =====================================================================
@app.get("/reports/summary", tags=["Reports"])
def summary(panel_id: Optional[int] = None, start: Optional[date] = None, end: Optional[date] = None):
    params = []
    where = " WHERE 1 = 1"
    if panel_id:
        where += " AND panel_id = ?"
        params.append(panel_id)
    where += date_filter("reading_date", start, end, params)
    totals = run_query(f"""
        SELECT COUNT(*) AS total_readings,
               IFNULL(ROUND(SUM(generated_kwh), 2), 0)  AS total_generated,
               IFNULL(ROUND(SUM(consumed_kwh), 2), 0)   AS total_consumed,
               IFNULL(ROUND(SUM(expected_kwh), 2), 0)   AS total_expected,
               IFNULL(ROUND(SUM(energy_balance), 2), 0) AS total_balance,
               IFNULL(ROUND(AVG(efficiency), 2), 0)     AS avg_efficiency,
               IFNULL(ROUND(SUM(savings), 2), 0)        AS total_savings
        FROM energy_readings{where}""", params, "one")
    totals["total_users"] = run_query("SELECT COUNT(*) AS c FROM users", fetch="one")["c"]
    totals["active_panels"] = run_query(
        "SELECT COUNT(*) AS c FROM solar_panels WHERE status = 'Active'", fetch="one")["c"]
    totals["open_alerts"] = run_query("SELECT COUNT(*) AS c FROM alerts WHERE status = 'Open'", fetch="one")["c"]
    return totals


@app.get("/reports/daily", tags=["Reports"])
def daily_report(panel_id: Optional[int] = None, start: Optional[date] = None, end: Optional[date] = None):
    params = []
    sql = """SELECT reading_date,
                    ROUND(SUM(generated_kwh), 2)  AS generated,
                    ROUND(SUM(consumed_kwh), 2)   AS consumed,
                    ROUND(SUM(expected_kwh), 2)   AS expected,
                    ROUND(SUM(energy_balance), 2) AS balance,
                    ROUND(SUM(generated_kwh) * 100.0 / SUM(expected_kwh), 2) AS efficiency,
                    ROUND(SUM(savings), 2)        AS savings
             FROM energy_readings WHERE 1 = 1"""
    if panel_id:
        sql += " AND panel_id = ?"
        params.append(panel_id)
    sql += date_filter("reading_date", start, end, params)
    return run_query(sql + " GROUP BY reading_date ORDER BY reading_date", params)


@app.get("/reports/monthly", tags=["Reports"])
def monthly_report(panel_id: Optional[int] = None):
    params = []
    sql = """SELECT strftime('%Y-%m', reading_date) AS month,
                    COUNT(*) AS readings,
                    ROUND(SUM(generated_kwh), 2)  AS generated,
                    ROUND(SUM(consumed_kwh), 2)   AS consumed,
                    ROUND(SUM(energy_balance), 2) AS balance,
                    ROUND(AVG(efficiency), 2)     AS avg_efficiency,
                    ROUND(SUM(savings), 2)        AS savings
             FROM energy_readings WHERE 1 = 1"""
    if panel_id:
        sql += " AND panel_id = ?"
        params.append(panel_id)
    return run_query(sql + " GROUP BY month ORDER BY month DESC", params)


@app.get("/reports/panels", tags=["Reports"])
def panel_report(start: Optional[date] = None, end: Optional[date] = None):
    params = []
    on_dates = date_filter("r.reading_date", start, end, params)
    return run_query(f"""
        SELECT p.panel_id, p.panel_name, u.name AS owner_name, p.capacity_kw, p.efficiency_limit, p.status,
               COUNT(r.reading_id)                        AS readings,
               IFNULL(ROUND(SUM(r.generated_kwh), 2), 0)  AS generated,
               IFNULL(ROUND(SUM(r.consumed_kwh), 2), 0)   AS consumed,
               IFNULL(ROUND(SUM(r.energy_balance), 2), 0) AS balance,
               IFNULL(ROUND(AVG(r.efficiency), 2), 0)     AS avg_efficiency,
               IFNULL(ROUND(MIN(r.efficiency), 2), 0)     AS min_efficiency,
               IFNULL(ROUND(SUM(r.savings), 2), 0)        AS savings,
               SUM(CASE WHEN r.efficiency < 60 THEN 1 ELSE 0 END) AS low_days
        FROM solar_panels p
        JOIN users u ON p.user_id = u.user_id
        LEFT JOIN energy_readings r ON p.panel_id = r.panel_id{on_dates}
        GROUP BY p.panel_id
        ORDER BY generated DESC""", params)


@app.get("/reports/users", tags=["Reports"])
def user_report():
    return run_query("""
        SELECT u.user_id, u.name, u.city,
               COUNT(DISTINCT p.panel_id)                 AS panels,
               IFNULL(ROUND(SUM(r.generated_kwh), 2), 0)  AS generated,
               IFNULL(ROUND(SUM(r.consumed_kwh), 2), 0)   AS consumed,
               IFNULL(ROUND(SUM(r.savings), 2), 0)        AS savings
        FROM users u
        LEFT JOIN solar_panels p    ON u.user_id = p.user_id
        LEFT JOIN energy_readings r ON p.panel_id = r.panel_id
        GROUP BY u.user_id
        ORDER BY savings DESC""")
