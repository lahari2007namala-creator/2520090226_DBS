"""Pydantic models: validate every request before it reaches the database."""
from datetime import date
from typing import Literal, Optional
from pydantic import BaseModel, Field


class UserCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=60)
    email: str = Field(..., pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    phone: Optional[str] = Field(None, max_length=15)
    city: Optional[str] = Field(None, max_length=40)


class PanelCreate(BaseModel):
    user_id: int = Field(..., gt=0)
    panel_name: str = Field(..., min_length=2, max_length=60)
    location: str = Field(..., min_length=2, max_length=80)
    capacity_kw: float = Field(..., gt=0, le=1000)
    sunlight_hours: float = Field(5.5, gt=0, le=24)
    cost_per_unit: float = Field(7.0, ge=0)
    efficiency_limit: float = Field(60.0, ge=1, le=100)
    installation_date: Optional[date] = None
    status: Literal["Active", "Inactive"] = "Active"


class ReadingCreate(BaseModel):
    panel_id: int = Field(..., gt=0)
    reading_date: date
    generated_kwh: float = Field(..., ge=0)
    consumed_kwh: float = Field(..., ge=0)


class MaintenanceCreate(BaseModel):
    panel_id: int = Field(..., gt=0)
    maintenance_date: date
    description: str = Field(..., min_length=3, max_length=200)
    technician: Optional[str] = None
    cost: float = Field(0, ge=0)
    status: Literal["Scheduled", "Completed"] = "Scheduled"
