-- =====================================================================
-- Solar Energy Management and Monitoring System - SQL Schema (SQLite)
-- Tables: users, solar_panels, energy_readings, alerts, maintenance
-- =====================================================================

PRAGMA foreign_keys = ON;

-- USERS : owners of solar panels
CREATE TABLE IF NOT EXISTS users (
    user_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    email       TEXT    NOT NULL UNIQUE,
    phone       TEXT,
    city        TEXT,
    created_at  TEXT    DEFAULT CURRENT_TIMESTAMP
);

-- SOLAR_PANELS : one user -> many panels
-- capacity_kw x sunlight_hours = expected daily output (Step 6)
CREATE TABLE IF NOT EXISTS solar_panels (
    panel_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id           INTEGER NOT NULL,
    panel_name        TEXT    NOT NULL,
    location          TEXT    NOT NULL,
    capacity_kw       REAL    NOT NULL CHECK (capacity_kw > 0),
    sunlight_hours    REAL    NOT NULL DEFAULT 5.5 CHECK (sunlight_hours > 0 AND sunlight_hours <= 24),
    cost_per_unit     REAL    NOT NULL DEFAULT 7 CHECK (cost_per_unit >= 0),
    efficiency_limit  REAL    NOT NULL DEFAULT 60 CHECK (efficiency_limit BETWEEN 1 AND 100),
    installation_date TEXT,
    status            TEXT    NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive')),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ENERGY_READINGS : one panel -> many daily readings
CREATE TABLE IF NOT EXISTS energy_readings (
    reading_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_id       INTEGER NOT NULL,
    reading_date   TEXT    NOT NULL,
    generated_kwh  REAL    NOT NULL CHECK (generated_kwh >= 0),
    consumed_kwh   REAL    NOT NULL CHECK (consumed_kwh >= 0),
    expected_kwh   REAL,
    efficiency     REAL,
    energy_balance REAL,
    savings        REAL,
    created_at     TEXT    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (panel_id) REFERENCES solar_panels(panel_id) ON DELETE CASCADE,
    UNIQUE (panel_id, reading_date)
);

-- ALERTS : created when efficiency < 60%
CREATE TABLE IF NOT EXISTS alerts (
    alert_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_id    INTEGER NOT NULL,
    reading_id  INTEGER NOT NULL,
    alert_type  TEXT    NOT NULL,
    message     TEXT    NOT NULL,
    severity    TEXT    NOT NULL CHECK (severity IN ('Medium', 'High')),
    status      TEXT    NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'Resolved')),
    created_at  TEXT    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (panel_id)   REFERENCES solar_panels(panel_id)      ON DELETE CASCADE,
    FOREIGN KEY (reading_id) REFERENCES energy_readings(reading_id) ON DELETE CASCADE
);

-- MAINTENANCE : service history of each panel
CREATE TABLE IF NOT EXISTS maintenance (
    maintenance_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    panel_id         INTEGER NOT NULL,
    maintenance_date TEXT    NOT NULL,
    description      TEXT    NOT NULL,
    technician       TEXT,
    cost             REAL    DEFAULT 0 CHECK (cost >= 0),
    status           TEXT    NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'Completed')),
    FOREIGN KEY (panel_id) REFERENCES solar_panels(panel_id) ON DELETE CASCADE
);
